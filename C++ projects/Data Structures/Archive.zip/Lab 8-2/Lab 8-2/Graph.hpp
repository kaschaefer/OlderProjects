//
//  Graph.hpp
//  Lab 8-2
//
//  Created by Mikaela Schaefer on 5/28/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#ifndef Graph_hpp
#define Graph_hpp

#include "Vertex.hpp"
#include <iostream>
#include "Stack.hpp"
#include <stdio.h>
////////////////////////////////////////////////////////////////
class Graph
{
private:
    static const int MAX_VERTS = 20;
    Vertex ** vertexList; // list of vertices
    int ** adjMat;      // adjacency matrix
    int nVerts;          // current number of vertices
    StackX * theStack;
    
public:
    Graph();               // constructor

    void addVertex(char lab) {              //Add new Vertex
        vertexList[nVerts++] = new Vertex(lab);
    }
    
    void addEdge(int start, int end) {      //Add Undirected Edge
        adjMat[start][end] = 1;
        adjMat[end][start] = 1;
    }
    
    void displayVertex(int v) {             //Display Vertex
        std::cout << vertexList[v]->label;
    }
    
    void dfs();  // depth-first search
    
    int getAdjUnvisitedVertex(int v);
    
    void mst();     //Minimum Spanning Tree method
};  // end class Graph
////////////////////////////////////////////////////////////////

#endif /* Graph_hpp */
