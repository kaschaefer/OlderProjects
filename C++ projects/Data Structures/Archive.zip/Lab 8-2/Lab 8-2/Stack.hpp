//


#ifndef Stack_hpp
#define Stack_hpp

#include <stdio.h>

// Translated from dfs.java by Brian Bird 5/31/2011
// Demonstrates a depth-first search of a graph
// Originallay from Data Structures and Algorithms in Java, 2nd Ed.
// by Robert Lafore


class StackX
{
private:
    static const int SIZE = 20;
    int * stackArray;
    int top;
    
public:
    StackX()      // constructor
    {
        stackArray = new int[SIZE];
        top = -1;
    }
    
    void push(int j)     // put item on top of stack
    {
        stackArray[++top] = j;
    }
    
    int pop()            // take item from top of stack
    {
        return stackArray[top--];
    }
    
    int peek()           // peek at top of stack
    {
        return stackArray[top];
    }
    
    bool isEmpty()    // true if stack is empty
    {
        return (top == -1);
    }
    
    bool isFull()     // true if stack is full
    {
        return (top == SIZE-1);
    }
    
    int size()           // return size
    {
        return top+1;
    }
    
    int peekN(int n)     // peek at index n
    {
        return stackArray[n];
    }
    
};  // end class StackX


#endif /* Stack_hpp */
