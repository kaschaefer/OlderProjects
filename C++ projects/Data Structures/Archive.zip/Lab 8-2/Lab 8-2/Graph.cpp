//
//  Graph.cpp
//  Lab 8-2
//
//  Created by Mikaela Schaefer on 5/28/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#include "Graph.hpp"

Graph::Graph(){
        vertexList = new Vertex * [MAX_VERTS];
        
        adjMat = new int * [MAX_VERTS];        // create and set
        for(int j=0; j<MAX_VERTS; j++)         //    matrix to 0
        {
            adjMat[j] = new int[MAX_VERTS];
            for(int k=0; k<MAX_VERTS; k++)
                adjMat[j][k] = 0;
        }
        
        nVerts = 0;
        theStack = new StackX();
}  // end constructor

// ------------------------------------------------------------
void Graph::dfs()  // depth-first search
{                                 // begin at vertex 0
    vertexList[0]->wasVisited = true;  // mark it
    displayVertex(0);                 // display it
    theStack->push(0);                 // push it
    
    while( !theStack->isEmpty() )      // until stack empty,
    {
        // get an unvisited vertex adjacent to stack top
        int v = getAdjUnvisitedVertex( theStack->peek() );
        if(v == -1)                    // if no such vertex,
            theStack->pop();
        else                           // if it exists,
        {
            vertexList[v]->wasVisited = true;  // mark it
            displayVertex(v);                 // display it
            theStack->push(v);                 // push it
        }
    }  // end while
    
    // stack is empty, so we're done
    for(int j=0; j<nVerts; j++)          // reset flags
        vertexList[j]->wasVisited = false;
}  // end dfs

// ------------------------------------------------------------
// returns an unvisited vertex adj to v
int Graph::getAdjUnvisitedVertex(int v)
{
    for(int j=0; j<nVerts; j++)
        if(adjMat[v][j]==1 && vertexList[j]->wasVisited==false)
            return j;
    return -1;
}  // end getAdjUnvisitedVertex()
// ------------------------------------------------------------

//Get a minimum spanning tree
void Graph::mst(){
    vertexList[0]->wasVisited = true;
    theStack->push(0);
    
    while ( !theStack->isEmpty() ) {
        int currentVertex = theStack->peek();
        int v = getAdjUnvisitedVertex(currentVertex);    //get next unvisited neighbor
        if (v == -1) {                                  //If No more neighbors
            theStack->pop();
        }
        else {                                      //Else there is a neighbor
            vertexList[v]->wasVisited = true;       //Mark It
            theStack->push(v);                      //Push it
            
            displayVertex(currentVertex);       //Display
            displayVertex(v);
            std::cout << " ";
        }
        
    }
    
    for (int j = 0; j < nVerts; j++) {          //Reset Flags
        vertexList[j]->wasVisited = false;
    }
        
}