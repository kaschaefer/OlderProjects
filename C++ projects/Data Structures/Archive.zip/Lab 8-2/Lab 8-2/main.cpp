/*
******************************************************************
 
 THIS IS A SOLUTION TO PART 1 OF LAB 8
 USING A DEPTH FIRST SEARCH TO CREATE A MINIMUM SPANNING TREE

 *****************************************************************
*/

#include <iostream>
#include "Graph.hpp"
using namespace std;

int main()
{
    Graph theGraph;
    
    theGraph.addVertex('A');    // 0  (start for dfs)
    theGraph.addVertex('B');    // 1
    theGraph.addVertex('C');    // 2
    theGraph.addVertex('D');    // 3
    theGraph.addVertex('E');    // 4
    
    theGraph.addEdge(0, 1);     // AB
    theGraph.addEdge(1, 2);     // BC
    theGraph.addEdge(0, 3);     // AD
    theGraph.addEdge(3, 4);     // DE
    
    cout << "Visits: ";
    theGraph.dfs();             // depth-first search
    cout << endl;
    
    cout << "Minimum Spanning Tree: " << endl;      //Testing MST method
    theGraph.mst();
    cout << endl << endl;
    
    
    //Testing Second Graph
    //nine	vertices	and	twelve	edges
    
    cout << "Creating Graph 2. Nine Vertices, Twelve Edges." << endl;
    
    Graph theGraph2;
    theGraph2.addVertex('A');    // 0
    theGraph2.addVertex('B');    // 1
    theGraph2.addVertex('C');    // 2
    theGraph2.addVertex('D');    // 3
    theGraph2.addVertex('E');    // 4
    theGraph2.addVertex('F');    // 5
    theGraph2.addVertex('G');    // 6
    theGraph2.addVertex('H');    // 7
    theGraph2.addVertex('I');    // 8
    
    theGraph2.addEdge(0, 1);     // AB   1
    theGraph2.addEdge(1, 2);     // BC   2
    theGraph2.addEdge(0, 3);     // AD   3
    theGraph2.addEdge(3, 4);     // DE   4
    theGraph2.addEdge(1, 5);    //BF    5
    theGraph2.addEdge(4, 6);    //EG    6
    theGraph2.addEdge(3, 7);    //DH    7
    theGraph2.addEdge(6, 8);    //GI    8
    theGraph2.addEdge(2, 3);    //CD    9
    theGraph2.addEdge(2, 7);    //CH    10
    theGraph2.addEdge(7, 8);    //HI    11
    theGraph2.addEdge(7, 0);    //HA    12
    
    cout << "Visits: ";
    theGraph2.dfs();
    cout << endl;
    
    cout << "Minimum Spanning Tree 2: " << endl;
    theGraph2.mst();
    cout << endl;
    
    return 0;
}  // end main()

////////////////////////////////////////////////////////////////

