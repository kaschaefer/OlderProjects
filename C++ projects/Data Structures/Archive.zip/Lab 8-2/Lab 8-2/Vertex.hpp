//
//  Vertex.hpp
//  Lab 8-2
//
//  Created by Mikaela Schaefer on 5/28/16.

#ifndef Vertex_hpp
#define Vertex_hpp

#include <stdio.h>
class Vertex
{
public:
    char label;        // label (e.g. 'A')
    bool wasVisited;
    
    Vertex(char lab)   // constructor
    {
        label = lab;
        wasVisited = false;
    }
};  // end class Vertex


#endif /* Vertex_hpp */
