//
//  Vertex.hpp
//  Lab 8-1
//
//  Created by Mikaela Schaefer on 5/28/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#ifndef Vertex_hpp
#define Vertex_hpp

#include <stdio.h>

class Vertex
{
public:
    char label;        // label (e.g. 'A')
    bool wasVisited;
    
    Vertex(char lab)   // constructor
    {
        label = lab;
        wasVisited = false;
    }
    
};  // end class Vertex


#endif /* Vertex_hpp */
