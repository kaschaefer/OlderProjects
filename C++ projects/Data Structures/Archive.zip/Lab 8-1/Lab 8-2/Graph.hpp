//
//  Graph.hpp
//  Lab 8-1
//
//  Created by Mikaela Schaefer on 5/28/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#ifndef Graph_hpp
#define Graph_hpp

#include <stdio.h>
#include "Vertex.hpp"
#include <iostream>
#include "Queue.hpp"


using namespace std;



class Graph
{
private:
    static const int MAX_VERTS = 20;
    Vertex ** vertexList; // list of vertices
    int ** adjMat;      // adjacency matrix
    int nVerts;          // current number of vertices
    Queue * theQueue;
    
public:
    Graph();
    
    void addVertex(char lab) {
        vertexList[nVerts++] = new Vertex(lab);
    }
    
    void addDirEdge(int start, int end) {       //Directed Edge
        adjMat[start][end] = 1;
    }
    
    void addEdge(int start, int end) {      //Undirected Edge
        adjMat[start][end] = 1;
        adjMat[end][start] = 1;
    }
    
    void displayVertex(int v) {
        cout << vertexList[v]->label;
    }
    
    void bfs();     //Breadth First Search
    
    void displayConnectivityTable(); //Display the Connectivity Table
    
    int getAdjUnvisitedVertex(int v);
    
};  // end class Graph

#endif /* Graph_hpp */
