//
//  Graph.cpp
//  Lab 8-1
//
//  Created by Mikaela Schaefer on 5/28/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#include "Graph.hpp"

Graph::Graph()               // constructor
{
    vertexList = new Vertex * [MAX_VERTS];
    
    adjMat = new int * [MAX_VERTS];        // create and set
    for(int j=0; j<MAX_VERTS; j++)         //    matrix to 0
    {
        adjMat[j] = new int[MAX_VERTS];
        for(int k=0; k<MAX_VERTS; k++)
            adjMat[j][k] = 0;
    }
    
    nVerts = 0;
    theQueue = new Queue();
}  // end constructor

void Graph::bfs()                   // breadth-first search
{                                // begin at vertex 0
    vertexList[0]->wasVisited = true; // mark it
    displayVertex(0);                // display it
    theQueue->insert(0);              // insert at tail
    int v2;
    
    while( !theQueue->isEmpty() )     // until queue empty,
    {
        int v1 = theQueue->remove();   // remove vertex at head
        
        // until it has no unvisited neighbors
        while( (v2=getAdjUnvisitedVertex(v1)) != -1 )
        {                                  // get one,
            vertexList[v2]->wasVisited = true;  // mark it
            displayVertex(v2);                 // display it
            theQueue->insert(v2);               // insert it
        }   // end while
    }  // end while(queue not empty)
    
    // queue is empty, so we're done
    for(int j=0; j<nVerts; j++)             // reset flags
        vertexList[j]->wasVisited = false;
    
}  // end bfs()



// returns an unvisited vertex adj to v
int Graph::getAdjUnvisitedVertex(int v)
{
    for(int j=0; j<nVerts; j++)
        if(adjMat[v][j]==1 && vertexList[j]->wasVisited==false)
            return j;
    return -1;
}  // end getAdjUnvisitedVertex()


void Graph::displayConnectivityTable() {
    int y;
    int x;
    int z;
    
    int ** tempAdjMat = adjMat;                 //Create a Temp Variable to Avoid Changes to the
                                                // Adjacency Matrix
    
    for ( y = 0; y < nVerts; y++) {             //Row, Then Used as Column
        for(x = 0; x < nVerts; x++) {           //Cells in the Row
            for (z = 0; z < nVerts; z++) {      //Looks down Row Y
                if (adjMat[x][y] * adjMat[y][z] != 0 && x != z) {   //If X to Y and Y to Z
                                                                    //And X same as Z
                    tempAdjMat[x][z] = 1;                               //Then X to Z
                }
            }
        }
    }
    
    for (int i =0; i < nVerts; i++ ) {          //Display the Updated Adjacency Matrix
        displayVertex(i);
        cout << " ";
        for (int j = 0; j < nVerts; j++) {
            if (tempAdjMat[i][j] != 0) {
                displayVertex(j);
            }
        }
        cout << endl;
    }
    
    delete [] tempAdjMat;       //Delete Temp Variable
    
}       //End Display Connectivity Table




