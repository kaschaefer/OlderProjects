//
//  Queue.cpp
//  Lab 8-1
//
//  Created by Mikaela Schaefer on 5/28/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#include "Queue.hpp"


Queue::Queue()            // constructor
{
    queArray = new int[SIZE];
    front = 0;
    rear = -1;
}

void Queue::insert(int j) // put item at rear of queue
{
    if(rear == SIZE-1)
        rear = -1;
    queArray[++rear] = j;
}

int Queue::remove()       // take item from front of queue
{
    int temp = queArray[front++];
    if(front == SIZE)
        front = 0;
    return temp;
}