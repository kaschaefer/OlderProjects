// bfs.cpp
// modified from bfs.java by jim bailey
// demonstrates breadth-first search

#include <iostream>
#include "Graph.hpp"

using namespace std;



int main(int argc, char * argv[])
{
    Graph theGraph;
    
    theGraph.addVertex('A');    // 0  (start for bfs)
    theGraph.addVertex('B');    // 1
    theGraph.addVertex('C');    // 2
    theGraph.addVertex('D');    // 3
    theGraph.addVertex('E');    // 4
    
    theGraph.addEdge(0, 1);     // AB
    theGraph.addDirEdge(1, 2);     // BC    //Directed Edge
    theGraph.addDirEdge(0, 3);     // AD    //Directed Edge
    theGraph.addEdge(3, 4);     // DE
    
    cout << "Visits: ";
    theGraph.bfs();             // breadth-first search
    cout << endl;
    
    theGraph.displayConnectivityTable();    //Test Connectivity Table With
    
}
