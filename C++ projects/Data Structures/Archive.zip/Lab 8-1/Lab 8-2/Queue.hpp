//
//  Queue.hpp
//  Lab 8-1
//
//  Created by Mikaela Schaefer on 5/28/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#ifndef Queue_hpp
#define Queue_hpp

#include <stdio.h>


class Queue
{
private:
    static const int SIZE = 20;
    int * queArray;
    int front;
    int rear;
    
public:
    Queue();
    
    void insert(int j);
    
    int remove();
    
    bool isEmpty() {  // true if queue is empty
        return ( rear+1 == front || (front+SIZE-1 == rear) );
    }
    
};  // end class Queue

#endif /* Queue_hpp */
