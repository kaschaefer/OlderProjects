//
//  Vertex.hpp
//  Lab 8
//
//  Created by Mikaela Schaefer on 5/28/16.
//
#ifndef Vertex_hpp

#define Vertex_hpp


#include <stdio.h>



class Vertex
{
public:
    char label;        // label (e.g. 'A')
    bool isInTree;
    
    Vertex(char lab)   // constructor
    {
        label = lab;
        isInTree = false;
    }
};  // end class Vertex

#endif //Vertex

