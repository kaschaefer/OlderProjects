//
//  DistPar.cpp
//  Lab 8
//
//  Created by Mikaela Schaefer on 5/28/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#include "DistPar.hpp"
