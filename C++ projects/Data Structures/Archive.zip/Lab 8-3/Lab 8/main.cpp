// path.cpp
// modified from path.java by jim bailey
// demonstrates shortest path with weighted, directed graphs

#include <iostream>
#include "Graph.hpp"

using namespace std;

int main(int argc, char * argv[])
{
    Graph theGraph;
    
    theGraph.addVertex('A');     // 0  (start)
    theGraph.addVertex('B');     // 1
    theGraph.addVertex('C');     // 2
    theGraph.addVertex('D');     // 3
    theGraph.addVertex('E');     // 4
    
    theGraph.addEdge(0, 1, 50);  // AB 50
    theGraph.addEdge(0, 3, 80);  // AD 80
    theGraph.addEdge(1, 2, 60);  // BC 60
    theGraph.addEdge(1, 3, 90);  // BD 90
    theGraph.addEdge(2, 4, 40);  // CE 40
    theGraph.addEdge(3, 2, 20);  // DC 20
    theGraph.addEdge(3, 4, 70);  // DE 70
    theGraph.addEdge(4, 1, 50);  // EB 50
    
    cout << "Shortest paths" << endl;
    theGraph.path();             // shortest paths
    cout << endl << endl;
    
    Graph theGraph2;
    
    theGraph2.addVertex('A');
    theGraph2.addVertex('B');
    theGraph2.addVertex('C');
    theGraph2.addVertex('D');
    
    theGraph2.addEdge(0, 1, 10);
    theGraph2.addEdge(1, 0, 10);
    theGraph2.addEdge(1, 2, 10);
    theGraph2.addEdge(2, 1, 10);
    theGraph2.addEdge(1, 3, 10);
    
    cout << " Shortest Paths " << endl;
    theGraph2.path();
    cout << endl;
    
}