//
//  Graph.hpp
//  Lab 8
//
//  Created by Mikaela Schaefer on 5/28/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#ifndef Graph_hpp
#define Graph_hpp

#include <stdio.h>
#include "Vertex.hpp"
#include "DistPar.hpp"
#include <iostream>


class Graph
{
private:
    static const int MAX_VERTS = 20;
    static const int INFINITY = 1000000;
    Vertex ** vertexList; // list of vertices
    int ** adjMat;      // adjacency matrix
    int nVerts;          // current number of vertices
    int nTree;           // number of verts in tree
    DistPar ** sPath;     // array for shortest-path data
    int currentVert;     // current vertex
    int startToCurrent;  // distance to currentVert
    
public:
    Graph();
    void displayMinimumCostTable();
    void addVertex(char lab) {vertexList[nVerts++] = new Vertex(lab);} //Add a Vertex
    void addEdge(int start, int end, int weight){adjMat[start][end] = weight;} //Add Directed Edge
    void path();
    int getMin();
    void adjust_sPath(int c);
    void displayPaths();
};  // end class Graph

#endif /* Graph_hpp */
