//
//  DistPar.hpp
//  Lab 8
//
//  Created by Mikaela Schaefer on 5/28/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#ifndef DistPar_hpp
#define DistPar_hpp

#include <stdio.h>

class DistPar             // distance and parent
{                      // items stored in sPath array
public:
    int distance;   // distance from start to this vertex
    int parentVert; // current parent of this vertex
    
    DistPar(int pv, int d)  // constructor
    {
        distance = d;
        parentVert = pv;
    }
};  // end class DistPar

#endif /* DistPar_hpp */
