//
//  Graph.cpp
//  Lab 8
//
//  Created by Mikaela Schaefer on 5/28/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#include "Graph.hpp"
#include <iostream>

using namespace std;

Graph::Graph()               // constructor
{
    vertexList = new Vertex * [MAX_VERTS];
    
    // adjacency matrix
    adjMat = new int * [MAX_VERTS];
    
    for(int j=0; j<MAX_VERTS; j++)     // create and set adj matrix to infinit
    {
        adjMat[j] = new int[MAX_VERTS];
        for(int k=0; k<MAX_VERTS; k++)
            adjMat[j][k] = INFINITY;
    }
    
    nVerts = 0;
    nTree = 0;
    sPath = new DistPar * [MAX_VERTS];    // shortest paths
}  // end constructor


void Graph::path()                // find all shortest paths
{
    for (int startTree = 0; startTree < nVerts; startTree++){             // start at vertex 0
    vertexList[startTree]->isInTree = true;
    nTree = 1;                     // put it in tree
    
    // transfer row of distances from adjMat to sPath
    for(int j=0; j<nVerts; j++)
    {
        int tempDist = adjMat[startTree][j];
        sPath[j] = new DistPar(startTree, tempDist);
    }
    
    // until all vertices are in the tree
    while(nTree < nVerts)
    {
        int indexMin = getMin();    // get minimum from sPath
        int minDist = sPath[indexMin]->distance;
        
        if(minDist == INFINITY)     // if all infinite
        {                           // or in tree,
            cout << "There are unreachable vertices" << endl;
            break;                  // sPath is complete
        }
        else
        {                        // reset currentVert
            currentVert = indexMin;  // to closest vert
            startToCurrent = sPath[indexMin]->distance;
            // minimum distance from startTree is
            // to currentVert, and is startToCurrent
        }
        
        // put current vertex in tree
        vertexList[currentVert]->isInTree = true;
        nTree++;
        adjust_sPath(startTree);             // update sPath[] array
    }  // end while(nTree<nVerts)
    
    displayPaths();                // display sPath[] contents
    
    nTree = 0;                     // clear tree
    for(int j=0; j<nVerts; j++)
        vertexList[j]->isInTree = false;
        
}  // end path()
}

int Graph::getMin()               // get entry from sPath
{                              //    with minimum distance
    int minDist = INFINITY;        // assume minimum
    int indexMin = 0;
    
    for(int j=1; j<nVerts; j++)    // for each vertex,
    {                           // if it's in tree and smaller than old one
        if( !vertexList[j]->isInTree && sPath[j]->distance < minDist )
        {
            minDist = sPath[j]->distance;
            indexMin = j;            // update minimum
        }
    }  // end for
    
    return indexMin;               // return index of minimum
}  // end getMin()


void Graph::adjust_sPath(int c)
{
    // adjust values in shortest-path array sPath
    int column = 0;
    
    while(column < nVerts)         // go across columns
    {
        
        // if this column's vertex already in tree, skip it
        if( vertexList[column]->isInTree )
        {
            column++;
            continue;
        }
        if (column == c) {
            column++;
            continue;
        }
        
        // calculate distance for one sPath entry
        // get edge from currentVert to column
        int currentToFringe = adjMat[currentVert][column];
        // add distance from start
        int startToFringe = startToCurrent + currentToFringe;
        // get distance of current sPath entry
        int sPathDist = sPath[column]->distance;
        
        // compare distance from start with sPath entry
        if(startToFringe < sPathDist)   // if shorter,
        {                            // update sPath
            sPath[column]->parentVert = currentVert;
            sPath[column]->distance = startToFringe;
        }
        
        column++;
    }  // end while(column < nVerts)
}  // end adjust_sPath()


void Graph::displayPaths()
{
    for(int j=0; j<nVerts; j++) // display contents of sPath[]
    {
        cout << vertexList[j]->label << "="; // B=
        
        if(sPath[j]->distance == INFINITY)
            cout << "inf";                  // inf
        else
            cout << sPath[j]->distance;      // 50
        
        char parent = vertexList[ sPath[j]->parentVert ]->label;
        cout << "(" << parent << ") ";       // (A)
    }
    cout << endl;
}
