//
//  DataItem.hpp
//  Lab 7
//
//  Created by Mikaela Schaefer on 5/21/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#ifndef DataItem_hpp
#define DataItem_hpp

#include <stdio.h>

class DataItem
{
private:
    int iData;               // data item (key)
    
public:
    DataItem(int ii)          // constructor
    {
        iData = ii;
    }
    
    int getKey()
    {
        return iData;
    }
};  // end class DataItem

#endif /* DataItem_hpp */
