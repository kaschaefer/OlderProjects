//
//  HashTable.hpp
//  Lab 7
//
//  Created by Mikaela Schaefer on 5/21/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#ifndef HashTable_hpp
#define HashTable_hpp

#include <stdio.h>
#include "DataItem.hpp"


class HashTable {
private:
    DataItem ** hashArray;    // array holds hash table (pointers to DataItems)
    int arraySize;
    int numItems;
    DataItem * nonItem;        // for removed items
    void rehashTable();
    
public:
    HashTable(int size);       // constructor
    int getSize () {return arraySize;}
    void displayTable();
    int hashFunc(int key) {return key % arraySize;}       // hash function
    void insert(DataItem * item); // insert a DataItem
    DataItem * remove(int key);  // remove a DataItem
    DataItem * find(int key);    // find item with key
    
    
};  // end class HashTable

#endif /* HashTable_hpp */
