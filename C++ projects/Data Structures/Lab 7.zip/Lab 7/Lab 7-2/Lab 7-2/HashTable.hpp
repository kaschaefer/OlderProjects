//
//  HashTable.hpp
//  Lab 7-2
//
//  Created by Mikaela Schaefer on 5/21/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#ifndef HashTable_hpp
#define HashTable_hpp

#include <stdio.h>
#include "DataItem.hpp"

class HashTable {
private:
    DataItem ** hashArray;
    int arraySize;
    int numItems;
    DataItem * nonItem;
    void rehashTable();
    int getKey(std::string name);
    
public:
    HashTable(int size);       // constructor
    int getSize () {return arraySize;}
    void displayTable();
    int hashFunc(int key) {return key % arraySize;}       // hash function
    void insert(DataItem * item); // insert a DataItem
    DataItem * remove(std::string name);  // remove a DataItem
    DataItem * find(std::string name);    // find item with key
};

#endif /* HashTable_hpp */
