// hash.cpp
// modified from hash.java by jim bailey
// demonstrates hash table with linear probing

#include <iostream>
using namespace std;

#include "HashTable.hpp"

int main(int argc, char * argv[] )
{
    DataItem * aDataItem;
    std::string initialStrings[9];
    int i = 0;
    initialStrings[i++] ="dog";
    initialStrings[i++] = "cat";
    initialStrings[i++] = "airplane";
    initialStrings[i++] = "x";
    initialStrings[i++] = "xx";
    initialStrings[i++] = "horse";
    initialStrings[i++] = "god";
    initialStrings[i++] = "number";
    initialStrings[i++] = "aaa";
    int size;
    std::string aKey;
    bool done = false;
    char choice;
    // get sizes
    cout << "Enter size of hash table: ";
    cin >> size;
    
    // make table
    HashTable theHashTable(size);
    for (int k = 0; k < 9; k++) {
        aDataItem = new DataItem(initialStrings[k]);
        theHashTable.insert(aDataItem);
    }
    
    //display table
    theHashTable.displayTable();
    
    //search for cow
    theHashTable.find("cow")? (cout << "Cow found.") : (cout << "Cow not found.") << endl;
    //search for horse
    theHashTable.find("horse")?(cout << "Horse found.") : (cout << "Horse not found.");
    cout << endl;
    //remove horse
    theHashTable.remove("horse")? (cout << "Horse removed.") : (cout << "Horse not removed.");
    cout << endl;
    //display modified table
    theHashTable.displayTable();
    
}  // end main()
