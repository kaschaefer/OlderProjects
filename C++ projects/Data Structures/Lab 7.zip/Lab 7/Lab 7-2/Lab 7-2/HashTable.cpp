//
//  HashTable.cpp
//  Lab 7-2
//
//  Created by Mikaela Schaefer on 5/21/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
///

#include "HashTable.hpp"
#include <iostream>

using namespace std;

HashTable::HashTable(int size)       // constructor
{
    arraySize = size;
    numItems = 0;
    hashArray = new DataItem * [arraySize];
    
    // create a nonItem with a key of -1
    nonItem = new DataItem("");
    
    // initialize array to NULLs
    for ( int i = 0; i < arraySize; i++ )
        hashArray[i] = NULL;
}

void HashTable::displayTable()
{
    cout << "Table: ";
    
    for(int j=0; j<arraySize; j++)
        if(hashArray[j] != NULL)
            cout << hashArray[j]->getName() << " ";
        else
            cout << "** ";
    
    cout << endl;
}

void HashTable::insert(DataItem * item) // insert a DataItem
{
    if (static_cast<double>(numItems)/static_cast<double>(arraySize) >= .5 && numItems/arraySize >0) {
        rehashTable();
    }
    // note, keep count one less than max to allow find to not loop forever
    if ( numItems == arraySize -1 ) {
        cout << "array is full, can not insert!!" << endl;
        return;
    }
    
    int key = item->getKey();      // extract key
    int hashVal = hashFunc(key);  // hash the key
    
    // until empty cell or removed cell,
    while(hashArray[hashVal] != NULL && hashArray[hashVal] != nonItem) {
        ++hashVal;                 // go to next cell
        hashVal %= arraySize;      // wraparound if necessary
    }
    
    hashArray[hashVal] = item;    // insert item
    numItems++;                   // increment count
}  // end insert()

void HashTable::rehashTable() {
    HashTable temp(arraySize*2);
    for (int i =0; i < arraySize-1; i++) {
        if (hashArray[i]->getKey() != -1) {
            temp.insert(hashArray[i]);
        }
    }
    delete [] hashArray;
    hashArray = temp.hashArray;
    arraySize *= 2;
}

int HashTable::getKey(std::string name) {       //Converts String to Its Unique Number
    int key = 0;
    for (int i = static_cast<int>(name.length()); i > 0; i--){
        key += name[i-1]*(10^(i-1));
    }
    return key;
}

DataItem * HashTable::remove(std::string name)  // remove a DataItem
{
    int key = getKey(name);
    int hashVal = hashFunc(key);  // hash the key
    
    while(hashArray[hashVal] != NULL)  // until empty cell,
    {
        // found the key?
        if(hashArray[hashVal]->getKey() == key)
        {
            DataItem * temp = hashArray[hashVal]; // save item
            hashArray[hashVal] = nonItem;       // remove item
            numItems--;                         // decrement count
            return temp;                        // return item
        }
        
        ++hashVal;                 // go to next cell
        hashVal %= arraySize;      // wraparound if necessary
    }
    
    return NULL;                  // can't find item
}  // end remove()

DataItem * HashTable::find(std::string name)    // find item with key
{
    int key = getKey(name);
    int hashVal = hashFunc(key);  // hash the key
    
    while(hashArray[hashVal] != NULL)  // until empty cell,
    {                               // found the key?
        if(hashArray[hashVal]->getKey() == key)
            return hashArray[hashVal];   // yes, return item
        
        ++hashVal;                 // go to next cell
        hashVal %= arraySize;      // wraparound if necessary
    }
    
    return NULL;                  // can't find item
}