//
//  Link.hpp
//  Lab 7-3
//
//  Created by Mikaela Schaefer on 5/22/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#ifndef Link_hpp
#define Link_hpp

#include <stdio.h>
#include <iostream>
#include "DataItem.hpp"

class Link {
private:
    DataItem * dData;
    Link * next;
    
public:
    Link(std::string name, Link * next = nullptr);
    Link * getNext(){return next;}
    void setNext(Link * aLink) {next = aLink;}
    int getKey() {return dData->getKey();}
    std::string getName(){return dData->getName();}
    void displayLink() {std::cout << dData->getName();}
    
};

#endif /* Link_hpp */
