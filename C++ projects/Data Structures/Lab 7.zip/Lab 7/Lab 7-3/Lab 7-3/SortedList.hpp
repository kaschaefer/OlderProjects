//
//  SortedList.hpp
//  Lab 7-3
//
//  Created by Mikaela Schaefer on 5/22/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#ifndef SortedList_hpp
#define SortedList_hpp

#include <stdio.h>
#include "Link.hpp"

class SortedList {
private:
    int makeKey(std::string name);
    
public:
    Link * first;
    SortedList() {first = nullptr;}
    void insert(Link * newlink);
    void remove(std::string key);
    Link * find(std::string key);
    void displayList();
};

#endif /* SortedList_hpp */
