//
//  HashTable.cpp
//  Lab 7-3
//
//  Created by Mikaela Schaefer on 5/22/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#include "HashTable.hpp"
#include <iostream>

using namespace std;

HashTable::HashTable(int size)       // constructor
{
    arraySize = size;
    numItems = 0;
    hashArray = new SortedList [arraySize];
    for (int j =0; j < arraySize; j++) {
        hashArray[j] = *new SortedList();
    }
}

void HashTable::displayTable() {
    cout << "Table: " << endl;
    
    for(int j=0; j<arraySize; j++){
        cout << j << ". ";              //Display Cell Number
        if(hashArray[j].first != nullptr) {
            hashArray[j].displayList();    //Display Linked List at that Cell
            cout << endl;
        }
        if (hashArray[j].first == nullptr) {
            cout << "**" << endl;
        }
    }
}

void HashTable::insert(Link * item) // insert a DataItem
{
    int key = item->getKey();      // extract key
    int hashVal = hashFunc(key);  // hash the key
    hashArray[hashVal].insert(item);       //Insert the Link at HashVal
    numItems++;                   // increment count
}  // end insert()


int HashTable::getKey(std::string name) {       //Converts String to Its Unique Number
    int key = 0;
    for (int i = static_cast<int>(name.length()); i > 0; i--){
        key += name[i-1]*(10^(i-1));
    }
    return key;
}

Link * HashTable::remove(std::string name)  // remove a DataItem
{
    int key = getKey(name);
    int hashVal = hashFunc(key);  // hash the key
    Link * temp = find(name);       //Temp will be null if not found
    if (temp != nullptr) {
        numItems--;
        hashArray[hashVal].remove(name);
    }
    return temp;
}  // end remove()

Link * HashTable::find(std::string name)    // find item with key
{
    int key = getKey(name);
    int hashVal = hashFunc(key);  // hash the key
    Link * temp = hashArray[hashVal].find(name);
    return temp;                                    //Temp will be null if not found
}