//
//  Link.cpp
//  Lab 7-3
//
//  Created by Mikaela Schaefer on 5/22/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#include "Link.hpp"

Link::Link(std::string name, Link * next){
    this->next = next;
    dData = new DataItem(name);
}