//
//  DataItem.hpp
//  Lab 7-3
//
//  Created by Mikaela Schaefer on 5/22/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#ifndef DataItem_hpp
#define DataItem_hpp

#include <stdio.h>
#include <string>

class DataItem
{
private:
    int iData;               // data item (key)
    std::string name;
    
public:
    DataItem(std::string name)          // constructor
    {
        this->name = name;
        int key =0;
        //Turn Name into an int key
        for (int i = static_cast<int>(name.length()); i > 0; i--){
            key += name[i-1]*(10^(i-1));
        }
        iData = key;
    }
    
    std::string getName() {
        return name;
    }
    
    int getKey()
    {
        return iData;
    }
};  // end class DataItem

#endif /* DataItem_hpp */