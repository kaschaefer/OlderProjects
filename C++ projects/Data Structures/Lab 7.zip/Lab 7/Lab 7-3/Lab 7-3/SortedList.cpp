//
//  SortedList.cpp
//  Lab 7-3
//
//  Created by Mikaela Schaefer on 5/22/16.
//  Copyright © 2016 Mikaela Schaefer. All rights reserved.
//

#include "SortedList.hpp"
#include <iostream>


void SortedList::insert(Link * newlink){
    int key = newlink->getKey();
    Link * previous = nullptr;      //Start at the first
    Link * current = first;
    
    while (current != nullptr && key > current->getKey()) {
        previous = current;
        current=current->getNext();
    }
    
    if (previous == nullptr) {      //the list is empty
        first = newlink;
    }
    else {
        previous->setNext(newlink);
    }
    newlink->setNext(current);
}   //end insert

int SortedList::makeKey(std::string name) {
    int key = 0;
    for (int i = static_cast<int>(name.length()); i > 0; i--){
        key += name[i-1]*(10^(i-1));
    }
    return key;
}

void SortedList::remove(std::string key){
    if (first == nullptr) {return;}     //The List is Empty
    
    if (find(key) == nullptr) {return;}     //The Key to Delete Isn't In the List
    
    int intKey = makeKey(key);          //Turn the string into its Numerical Key
    Link * previous = nullptr;
    Link * current = first;
    
    while (current != nullptr && intKey != current->getKey()) {
        previous = current;
        current = current->getNext();
    }
    
    if (previous == nullptr) {              //Found at Beginning of the list
        first = first->getNext();
    }
    else {                                  //Not at the Beginning
        previous->setNext(current->getNext());
    }
}   //End Delete

Link * SortedList::find(std::string key) {
    int intKey = makeKey(key);      //Get Numerical Key from String
    Link * current = first;
    
    while (current != nullptr && current->getKey() <= intKey) { //Until End of List or Key Too Small
        if (current->getKey() == intKey) {
            return current;
        }
        current = current->getNext();       //Go to Next Link
    }
    return nullptr;     //Didn't Find It
}


void SortedList::displayList() {
    Link * current = first;
    while (current != nullptr) {
        current->displayLink();
        if (current->getNext()!= nullptr) {
            std::cout << " -> ";
        }
        current = current->getNext();
    }
}





