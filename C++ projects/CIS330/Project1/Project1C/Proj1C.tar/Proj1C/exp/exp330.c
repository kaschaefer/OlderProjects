#include <math330.h>
#include <math.h>

double exp330(double angle)
{
    return exp(angle);
}
