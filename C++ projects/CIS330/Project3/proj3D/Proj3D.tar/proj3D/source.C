#include <source.h>

Image * Source::GetOutput(){
	Image *img = &theImg;
	return img;
}
